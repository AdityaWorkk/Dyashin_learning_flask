from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flasgger import Swagger
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_migrate import Migrate
from core.config import Config
from model import db  # Assuming db is defined in model.py
from core.logging import setup_logging
from flask_pymongo import PyMongo

# Initialize extensions without the app first
migrate = Migrate()
jwt = JWTManager()
swagger = Swagger()
mongo = PyMongo()
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"], # Fallback limits
    storage_uri="memory://" 
)

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize Logging
    setup_logging(app)

    

    # Bind extensions to the app
    db.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)
    jwt.init_app(app)
    swagger.init_app(app)
    
    # 1. Initialize MongoDB
    mongo.init_app(app)
    
    # Limiter needs special handling for default limits from config
    limiter.init_app(app)

    # Register Blueprints
    from .endpoints.routes import main_bp
    app.register_blueprint(main_bp)

    return app


