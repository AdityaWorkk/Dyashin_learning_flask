from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, create_access_token
from model import db, User, Product, CartItem
from flask import current_app
from app import db, limiter 
from model import User, Product, CartItem
from app.schema.ecommerce_schema import UserSchema, ProductSchema, CartResponseSchema
from app import mongo # Ensure this is imported from your __init__.py
from datetime import datetime
import bcrypt # Recommended for password hashing
from app import limiter
from datetime import datetime



# Create the Blueprint
main_bp = Blueprint('main', __name__)    #main blueprint

@main_bp.errorhandler(429)
def ratelimit_handler(e):
    return jsonify({"error": "Slow down! You have exceeded your request limit."}), 42


# Initialize schemas
user_schema = UserSchema()
product_schema = ProductSchema(many=True) # 'many=True' for lists
cart_response_schema = CartResponseSchema()


# --- HELPER FUNCTIONS ---

def check_admin():
    username = get_jwt_identity()
    user = mongo.db.users.find_one({"username": username})
    if user:
        return user.get('is_admin', False)   #return true if admin else false
    return False #If the the db couldn't find any person

def get_next_sequence_value(sequence_name):
    # This finds the counter document and increments the 'sequence_value' by 1
    result = mongo.db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        upsert=True,  # Create it if it doesn't exist
        return_document=True
    )
    return result["sequence_value"]


# --- AUTH ROUTES ---

@main_bp.route('/register', methods=['POST'])
@limiter.limit("5 per minute") # Stricter limit to prevent bot spam
def register():
    """
        User Registration with Email
        ---
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [username, email, password]
              properties:
                username: {type: string, example: admin_user}
                email: {type: string, example: admin123@gmail.com}
                password: {type: string, example: "password123"}
                is_admin: {type: boolean, example: false}
        responses:
          201:
            description: User registered successfully
          400:
            description: Username or Email already exists
    """

    data = request.json

    # 2. This step triggers the "Unknown field" error if is_admin is missing from Schema
    errors = user_schema.validate(data) 
    if errors:
        return jsonify(errors), 400
    
    # 1. Generate the next numeric User ID
    new_user_id = get_next_sequence_value("user_id")

    # 2. Check for existing user in MongoDB
    # SQL: User.query.filter(...) -> MongoDB: mongo.db.users.find_one(...)
    existing_user = mongo.db.users.find_one({
        "$or": [
            {"username": data['username']},
            {"email": data['email']}
        ]
    })

    if existing_user:
        return jsonify({"message": "Username or Email already exists"}), 400
        
    new_user = {
    "_id": new_user_id,
    "username": data['username'], 
    "email": data['email'],
    "password": data['password'],
    "is_admin": data.get('is_admin', False),
    "created_at": datetime.utcnow()
    }
    
    # 4. Insert into MongoDB
    # SQL: db.session.add() + commit() -> MongoDB: insert_one()
    mongo.db.users.insert_one(new_user)
    
    return jsonify({"message": f"User {new_user_id} registered successfully"}), 201

@main_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    """
        User Login
        ---
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [username, password]
              properties:
                username: {type: string, example: admin_user}
                password: {type: string, example: password123}
        responses:
          200:
            description: Returns a JWT token
            schema:
              properties:
                access_token:
                  type: string
                  example: "eyJhbGciOiJIUzI1Ni..."
          401:
            description: Bad credentials
        """
    data = request.json
    user = mongo.db.users.find_one({"username": data['username'], "password": data['password']})
    
    if user:
        token = create_access_token(identity=user['username'])
        return jsonify(access_token=token), 200
        
    return jsonify({"message": "Bad credentials"}), 401

@main_bp.route('/user/update_profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """
        Update User Credentials (Self Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [current_email, current_password]
              properties:
                current_email: {type: string, description: Verify identity}
                current_password: {type: string, description: Verify identity}
                new_username: {type: string}
                new_email: {type: string}
                new_password: {type: string}
        responses:
          200: {description: Profile updated}
          401: {description: Verification failed}
    """

    current_username = get_jwt_identity()
    data = request.json
    user = mongo.db.users.find_one({"username": current_username})

    if user['email'] != data.get('current_email') or user['password'] != data.get('current_password'):
        return jsonify({"message": "Identity verification failed."}), 401

    updates = {}
    if 'new_username' in data: updates['username'] = data['new_username']
    if 'new_email' in data: updates['email'] = data['new_email']
    if 'new_password' in data: updates['password'] = data['new_password']

    mongo.db.users.update_one({"username": current_username}, {"$set": updates})
    return jsonify({"message": "Credentials updated successfully."}), 200

@main_bp.route('/user/delete_profile', methods=['DELETE'])
@jwt_required()
def delete_profile():
    """
        Delete User Account (Self Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [password]
              properties:
                password: {type: string, description: "Confirm password to delete account"}
        responses:
          200:
            description: Account deleted successfully
          401:
            description: Password verification failed
          404:
            description: User not found
    """

    current_username = get_jwt_identity()
    user = mongo.db.users.find_one({"username": current_username})
    data = request.json

    if not user or user['password'] != data.get('password'):
        return jsonify({"message": "Verification failed."}), 401

    # Remove cart and user
    mongo.db.carts.delete_many({"username": current_username})
    mongo.db.users.delete_one({"username": current_username})
    return jsonify({"message": "Account deleted."}), 200



# --- PRODUCT ROUTES ---

@main_bp.route('/products', methods=['GET'])
@jwt_required()
def get_products():
    """
        Get all products
        ---
        security:
          - Bearer: []
        responses:
          200:
            description: A list of products
            schema:
              type: array
              items:
                properties:
                  id:
                    type: integer
                  name:
                    type: string
                  price:
                    type: number
                inventory: {type: integer, description: "Only visible to admins"}
          401:
            description: Missing or invalid token
    """

    products = list(mongo.db.products.find())
    is_admin = check_admin()
    
    product_list = []
    for p in products:
        p_data = {"id": str(p['_id']), "name": p['name'], "price": p['price']}
        if is_admin:
            p_data["inventory"] = p.get('inventory', 0)
        product_list.append(p_data)


    return jsonify(product_list)

  

# --- CART ROUTES ---

@main_bp.route('/cart/add', methods=['POST'])
@jwt_required()
def add_to_cart():
    """
    Add to cart and deduct from inventory
    ---
    security:
      - Bearer: []
    parameters:
      - name: body
        in: body
        required: true
        schema:
          properties:
            product_id: {type: integer}
            quantity: {type: integer, default: 1}
    responses:
      201: {description: Added to cart}
      400: {description: Insufficient stock}
    """

    from bson.objectid import ObjectId
    username = get_jwt_identity()
    data = request.json
    product_id = data.get('product_id') # This should be the string hex ID
    quantity = data.get('quantity', 1) 

    # Ensure product_id is treated as an integer
    try:
        product_id = int(data.get('product_id')) 
    except (ValueError, TypeError):
        return jsonify({"message": "Invalid product ID format"}), 400

    # REMOVE ObjectId() wrapper here
    product = mongo.db.products.find_one({"_id": product_id})

    if not product:
        return jsonify({"message": "Product not found"}), 404
    
    if product['inventory'] < quantity:
        return jsonify({"message": "Insufficient stock"}), 400

    # Atomic update for inventory
    mongo.db.products.update_one({"_id": product_id}, {"$inc": {"inventory": -quantity}})

    mongo.db.carts.update_one(
        {"username": username, "product_id": product_id},
        {"$inc": {"quantity": quantity}, "$set": {"product_name": product['name'], "price": product['price']}},
        upsert=True
    )

    return jsonify({"message": "Added to cart"}), 201

@main_bp.route('/cart', methods=['GET'])
@jwt_required()
def view_cart():
    """
    View current user's shopping cart
    ---
    security:
      - Bearer: []
    responses:
      200:
        description: List of items in the cart with total price
        schema:
          properties:
            items:
              type: array
              items:
                properties:
                  product_id: {type: integer}
                  product_name: {type: string}
                  price_per_unit: {type: number}
                  quantity: {type: integer}
                  subtotal: {type: number}
            grand_total: {type: number}
      401:
        description: Unauthorized
    """
    username = get_jwt_identity()
    
    # In MongoDB, we can store cart items in a 'carts' collection
    # linked by the unique username
    cart_items = list(mongo.db.carts.find({"username": username}))
    
    output = []
    grand_total = 0
    
    for item in cart_items:
        # Fetch the current product details to ensure price is up to date
        # item['product_id'] is now an int, so don't use ObjectId()
        product = mongo.db.products.find_one({"_id": int(item['product_id'])})
        if product:
            subtotal = product['price'] * item['quantity']
            grand_total += subtotal
            output.append({
                "product_id": str(product['_id']),
                "product_name": product['name'],
                "price_per_unit": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })

    result = {
        "items": output,
        "grand_total": grand_total
    }
    
    return jsonify(cart_response_schema.dump(result)), 200

@main_bp.route('/cart/update', methods=['POST'])
@jwt_required()
def update_cart():
    """
    Reduce quantity or remove item from cart
    ---
    security:
      - Bearer: []
    parameters:
      - name: body
        in: body
        required: true
        schema:
          required: [product_id, action]
          properties:
            product_id: {type: integer}
            action: {type: string, enum: [reduce, remove], example: reduce}
            quantity: {type: integer, default: 1, description: "Amount to reduce by if action is 'reduce'"}
    responses:
      200: {description: Cart updated successfully}
      404: {description: Item not found in cart}
    """
    username = get_jwt_identity()
    data = request.json
    
    product_id = data.get('product_id')
    action = data.get('action') # 'reduce' or 'remove'
    reduce_qty = data.get('quantity', 1)

    # Find the specific item in the user's cart
    cart_item = mongo.db.carts.find_one({
        "username": username, 
        "product_id": product_id
    })

    if not cart_item:
        return jsonify({"message": "Item not found in your cart"}), 404

    # Handle Removal or Reduction logic
    if action == 'remove' or (action == 'reduce' and cart_item['quantity'] <= reduce_qty):
        # Return units back to product inventory
        mongo.db.products.update_one(
          {"_id": int(product_id)}, 
          {"$inc": {"inventory": cart_item['quantity']}}
        )
        # Delete the cart document
        mongo.db.carts.delete_one({"_id": cart_item['_id']})
        message = "Item removed from cart"
    
    elif action == 'reduce':
        # Deduct quantity from cart and return specified units to inventory
        mongo.db.carts.update_one(
            {"_id": cart_item['_id']},
            {"$inc": {"quantity": -reduce_qty}}
        )
        mongo.db.products.update_one({"_id": product_id}, {"$inc": {"inventory": cart_item['quantity']}})
        message = f"Quantity reduced by {reduce_qty}"

    return jsonify({"message": message}), 200


@main_bp.route('/checkout', methods=['GET'])
@jwt_required()
def checkout():
    """
        Calculate total price and clear cart
        ---
        security:
          - Bearer: []
        responses:
          200:
            description: Checkout successful
            schema:
              properties:
                total_price: {type: number}
                status: {type: string}
                items_purchased: {type: integer}
          400:
            description: Cart is empty
    """

    username = get_jwt_identity()
    
    # Get all items in user's cart
    items = list(mongo.db.carts.find({"username": username}))

    if not items:
        return jsonify({"message": "Cart is empty"}), 400

    total = 0
    for i in items:
        product = mongo.db.products.find_one({"_id": int(i['product_id'])})
        if product:
            total += product['price'] * i['quantity']

    # Clear the cart for this user
    mongo.db.carts.delete_many({"username": username})
    
    # In MongoDB, you could also save this to an 'orders' collection here!
    return jsonify({
        "total_price": total, 
        "status": "Paid",
        "items_purchased": len(items)
    }), 200

# --- ADMIN ROUTES ---

@main_bp.route('/admin/products', methods=['POST'])
@jwt_required()
def add_product():
    """
        Add a new product with inventory (Admin Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required:
                - name
                - price
                - inventory
              properties:
                name: {type: string}
                price: {type: number}
                inventory: {type: integer, example: 50}
        responses:
          201:
            description: Product added successfully
    """
    if not check_admin():
        return jsonify({"message": "Admin only"}), 403
    
    data = request.json

    # Generate the next numeric ID (1, 2, 3...)
    new_id = get_next_sequence_value("product_id")

    # MongoDB inserts a plain dictionary
    new_product = {
        "_id": new_id,  # We manually set _id to the number
        "name": data['name'],
        "price": data['price'],
        "inventory": data['inventory'],
        "created_at": datetime.utcnow()
    }
    
    result = mongo.db.products.insert_one(new_product)
    return jsonify({
        "message": "Product added", 
        "product_id": new_id
    }), 201


@main_bp.route('/admin/users', methods=['GET'])
@jwt_required()
def list_users():
    """
        Delete a product (Admin Only)
        ---
        security:
          - Bearer: []
        
        responses:
          200:
            description: Product deleted successfully
          403:
            description: Admin privilege required
          404:
            description: Product not found
    """
    if not check_admin():
        return jsonify({"message": "Admin only"}), 403
        
    # Find all users and convert the cursor to a list
    users = list(mongo.db.users.find())
    
    # Convert MongoDB documents to a JSON-friendly format
    output = []
    for u in users:
        output.append({
            "id": str(u['_id']), 
            "username": u['username'],
            "email": u.get('email'),
            "is_admin": u.get('is_admin', False)
        })
        
    return jsonify(output), 200

