from marshmallow import Schema, fields, validate

# --- USER SCHEMAS ---
class UserSchema(Schema):
    # MongoDB returns _id as an ObjectId; this maps it to 'id' as a string for JSON
    id = fields.Int(dump_only=True, attribute="_id")
    username = fields.Str(required=True, validate=validate.Length(min=3))
    email = fields.Email(required=True)
    # The presence of this field fixes the "Unknown field" error
    is_admin = fields.Bool(load_default=False, dump_default=False) 
    # password is load_only so it is never sent back to the client
    password = fields.Str(required=True, load_only=True, validate=validate.Length(min=6))

# --- PRODUCT SCHEMAS ---
class ProductSchema(Schema):
    id = fields.Int(attribute="_id") # Map numeric _id to id
    name = fields.Str(required=True, validate=validate.Length(min=1))
    price = fields.Float(required=True, validate=validate.Range(min=0))
    inventory = fields.Int(required=True, validate=validate.Range(min=0))

# --- CART SCHEMAS ---
class CartItemSchema(Schema):
    id = fields.Int(dump_only=True)
    product_id = fields.Int(required=True)
    product_name = fields.Str(dump_only=True) # Used for display in view_cart
    quantity = fields.Int(required=True, validate=validate.Range(min=1))
    price_per_unit = fields.Float(dump_only=True)
    subtotal = fields.Float(dump_only=True)

class CartResponseSchema(Schema):
    items = fields.List(fields.Nested(CartItemSchema))
    grand_total = fields.Float()