import os
from datetime import timedelta

class Config:
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///ecommerce.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # MongoDB Integration
    MONGO_URI = os.environ.get('MONGO_URI') or 'mongodb://localhost:27017/ecommerce_db'
    
    # Security
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or 'your_super_secret_key'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=30)
    
    # Rate Limiting
    RATELIMIT_DEFAULT = "200 per day, 50 per hour"
    RATELIMIT_STORAGE_URI = "memory://"
    
    # Swagger UI
    SWAGGER = {
        'title': 'Ecommerce API',
        'uiversion': 3,
        'specs_route': '/apidocs/',
        'securityDefinitions': {
            'Bearer': {
                'type': 'apiKey',
                'name': 'Authorization',
                'in': 'header',
                'description': 'JWT Authorization header using the Bearer scheme. Example: "Bearer <token>"'
            }
        }
    }

