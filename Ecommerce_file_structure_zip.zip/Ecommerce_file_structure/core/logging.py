import logging
import os
from logging.handlers import RotatingFileHandler

def setup_logging(app):
    """Configures the logging behavior for the entire application."""
    
    # 1. Set the global log level
    log_level = logging.INFO
    if app.config.get('DEBUG'):
        log_level = logging.DEBUG

    # 2. Define the Log Format
    # Includes timestamp, log level, module name, and the message
    formatter = logging.Formatter(
        '[%(asctime)s] %(levelname)s in %(module)s: %(message)s'
    )

    # 3. Console Handler (Outputs to your terminal)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    app.logger.addHandler(console_handler)

    # 4. Rotating File Handler (Saves to a file, prevents it from getting too large)
    if not os.path.exists('logs'):
        os.mkdir('logs')
        
    file_handler = RotatingFileHandler(
        'logs/ecommerce.log', 
        maxBytes=10240, 
        backupCount=10
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)

    app.logger.setLevel(log_level)
    app.logger.info('Logging system initialized')

    