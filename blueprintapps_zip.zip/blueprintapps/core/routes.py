from flask import Flask, render_template, Blueprint
from blueprintapps import app

core = Blueprint("core", __name__, template_folder="templates")  #Blueprint("blueprint_name",__name__,template_folder="templates_stored_name")
#todos will be what we are returning



@core.route("/")
def index():
    return render_template("core/index.html")  






