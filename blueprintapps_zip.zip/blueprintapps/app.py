from flask import Flask,render_template,Blueprint
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate





db = SQLAlchemy()

def create_app():
    app = Flask(__name__,template_folder="templates")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///./blueprints.db"

    db.init_app(app)

    #app.config["SECRET KEY"] = ""

    #Enter and register all your bluepprints here
    from blueprintapps.todos.routes import todos
    from blueprintapps.people.routes import people
    from blueprintapps.core.routes import core

    app.register_blueprint(core, url_prefix="/")           #the landing page is this, url_prefix="/foldername"
    app.register_blueprint(todos, url_prefix="/todos")
    app.register_blueprint(people, url_prefix="/people")

    migrate = Migrate(app, db)

    return app


