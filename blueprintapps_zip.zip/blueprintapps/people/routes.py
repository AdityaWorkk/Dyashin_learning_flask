from flask import Flask, render_template, request, url_for, redirect, Blueprint
from blueprintapps import app
from blueprintapps.app import db
from blueprintapps.people.model import People

people = Blueprint("people", __name__, template_folder="templates")  #Blueprint("blueprint_name",__name__,template_folder="templates_stored_name")
#todos will be what we are returning



@people.route("/")
def index():
    people = People.query.all()
    return render_template("people/index.html", people=people)  #html variable=flask backend variable

@people.route("/create",methods=["GET","POST"])
def create():
    if request.method == "GET":
        return render_template("people/create.html")
    elif request.method == "POST":
        name = request.form.get("name")
        age = request.form.get("age")
        #done = True if done in request.form.keys() else False #If the checkbox is checked(clicked) then it will added into forms data else it will be just empty and not present in keys
        
        #description = description if description != "" else None

        people = People(name=name, age=age)

        db.session.add(people)
        db.session.commit()

        return redirect(url_for("people.index"))




