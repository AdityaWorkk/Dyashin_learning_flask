from flask import render_template, request, url_for, redirect, Blueprint
# REMOVED: from blueprintapps import app (Circular import)
from blueprintapps.app import db # Import db from where it's defined
from blueprintapps.todos.model import Todo


# Ensure template_folder matches your actual folder name (usually "templates")
todos = Blueprint("todos", __name__, template_folder="templates")

@todos.route("/")
def index():
    todos = Todo.query.all() # Renamed to avoid shadowing the blueprint name
    return render_template("todos/index.html", todos=todos)

@todos.route("/create", methods=["GET", "POST"])
def create():
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        
        # FIXED: Check for the string "done" in keys
        done = True if "done" in request.form else False
        
        description = description if description != "" else None

        todo = Todo(title=title, description=description, done=done)

        db.session.add(todo)
        db.session.commit()

        return redirect(url_for("todos.index"))
    
    # GET request
    return render_template("todos/create.html")

