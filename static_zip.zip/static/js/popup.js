window.onload = function() {
    // Corrected: use ( ) for the function call and remove the ; before the closing paren
    setTimeout(function() {
        alert("Welcome popup");
    }, 5000); //5 seconds
};  