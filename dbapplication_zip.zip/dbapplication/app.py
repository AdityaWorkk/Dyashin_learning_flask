from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_bcrypt import Bcrypt


#remember that flask doesn't has true database support

db = SQLAlchemy()


#We use function so that it can only execute when called to prevent circular imports
def create_app():
    app = Flask(__name__,template_folder="templates")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///./test.db"       #creates the sqlite database in the same directory("./")

    db.init_app(app)

    #Import api endpoints(or routes) later on so we can add values in the columns
    #Rather than "from models import people we do import from routes" to prevent circular imports
    from routes import register_route
    register_route(app, db)

    migrate = Migrate(app, db)  #we have to migrate(move the data) from app to db

    return app






