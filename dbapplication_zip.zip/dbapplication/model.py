#this python acts the ORM(Object Relational Mapping)

from app import db
from flask_login import UserMixin

class person(db.Model):
    __tablename__ = "people"

    pid = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable = False)
    age = db.Column(db.Integer)
    job = db.Column(db.String(100))

    def __repr__(self):      #Dunder method to officially define strings and print when called 
        return f"Person with {self.name} and age {self.age}"
    

class Users(db.Model, UserMixin):
    __tablename__ = "user"

    uid = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(100))
    description = db.Column(db.String(100))

    def __repr__(self):
        return f"<name: {self.username}, role: {self.role}>"
    
    def get_id(self):
        return self.uid
    
    

    
