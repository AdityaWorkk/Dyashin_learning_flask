from model import person
from flask import render_template, request, jsonify


#to prevent circular import we use a function to encase the index route
def register_route(app, db):

    @app.route("/", methods= ["POST","GET"])
    def index():
        if request.method == "GET":
            people = person.query.all()
            return render_template("8_sqlalchemy.html", people=people)
        elif request.method == "POST":
            name = request.form.get("name")    #GET name from sqlite database and POST it to the user
            age = int(request.form.get("age"))
            job = request.form.get("job")

            pers = person(name=name, age=age, job=job)

            db.session.add(pers)
            db.session.commit()

            people = person.query.all()
            return render_template("8_sqlalchemy.html", people=people)
        
    @app.route("/delete/<int:pid>", methods=["DELETE"])
    def delete_person(pid):
        pers = person.query.get_or_404(pid)
        db.session.delete(pers)
        db.session.commit()
        return {"success": True}, 200
    
    @app.route("/details/<pid>")
    def details(pid):
        pers = person.query.filter(person.pid == pid).first()

        return jsonify({
        "pid": pers.pid,
        "name": pers.name,
        "age": pers.age,
        "job": pers.job
    })

    @app.route("/details_page/<pid>")
    def details_page(pid):

        pers = person.query.filter(person.pid == pid).first()

        return render_template("details.html", pers=pers)
    

