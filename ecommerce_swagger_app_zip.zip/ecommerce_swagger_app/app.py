from flask import Flask, request, jsonify
from flasgger import Swagger
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from model import db, User, Product, CartItem
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from datetime import timedelta
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address


def create_app():
    app = Flask(__name__)
    
    # Configurations
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ecommerce.db'
    app.config['JWT_SECRET_KEY'] = 'your_super_secret_key'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Set token expiration (e.g., 30 minutes, 1 hour, or 1 day)
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=30)

    
    # Initialize Limiter
    # key_func=get_remote_address uses the user's IP address to track limits
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=["200 per day", "50 per hour"],
        storage_uri="memory://", # Use Redis in production for persistence
    )


    # Swagger Config for JWT Authorization
    app.config['SWAGGER'] = {
        'title': 'Ecommerce API',
        'uiversion': 3,
        'specs_route': '/apidocs/',
        'securityDefinitions': {
            'Bearer': {
                'type': 'apiKey',
                'name': 'Authorization',
                'in': 'header',
                'description': 'JWT Authorization header using the Bearer scheme. Example: "Bearer <token>"'
            }
        }
    }

    db.init_app(app)
    migrate = Migrate(app, db, render_as_batch=True)
    jwt = JWTManager(app)
    swagger = Swagger(app)

    # --- HELPER FUNCTIONS ---
    def check_admin():
        identity = get_jwt_identity()
        # Identity is the dictionary we put in create_access_token
        username = get_jwt_identity() # This is now just a string
        user = User.query.filter_by(username=username).first()
        return user.is_admin if user else False

    # --- AUTH ROUTES ---

    @app.route('/register', methods=['POST'])
    @limiter.limit("5 per minute") # Stricter limit to prevent bot spam
    def register():
        """
        User Registration with Email
        ---
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [username, email, password]
              properties:
                username: {type: string, example: admin_user}
                email: {type: string, example: admin123@gmail.com}
                password: {type: string, example: "password123"}
                is_admin: {type: boolean, example: false}
        responses:
          201:
            description: User registered successfully
          400:
            description: Username or Email already exists
        """
        data = request.json
        if User.query.filter((User.username == data['username']) | (User.email == data['email'])).first():
            return jsonify({"message": "Username or Email already exists"}), 400
            
        new_user = User(
            username=data['username'], 
            email=data['email'],
            password=data['password'],
            is_admin=data.get('is_admin', False)
        )
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"message": "User registered successfully"}), 201

    @app.route('/login', methods=['POST'])
    @limiter.limit("10 per minute") # Prevent brute-force password guessing
    def login():
        """
        User Login
        ---
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [username, password]
              properties:
                username: {type: string, example: admin_user}
                password: {type: string, example: password123}
        responses:
          200:
            description: Returns a JWT token
            schema:
              properties:
                access_token:
                  type: string
                  example: "eyJhbGciOiJIUzI1Ni..."
          401:
            description: Bad credentials
        """
        data = request.json
        # Identity check
        user = User.query.filter_by(username=data['username'], password=data['password']).first()
        
        if user:
            # We store the username in the identity
            token = create_access_token(identity=user.username)
            return jsonify(access_token=token), 200
            
        return jsonify({"message": "Bad credentials"}), 401
    
    @app.route('/user/update_profile', methods=['PUT'])
    @jwt_required()
    def update_profile():
        """
        Update User Credentials (Self Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [current_email, current_password]
              properties:
                current_email: {type: string, description: Verify identity}
                current_password: {type: string, description: Verify identity}
                new_username: {type: string}
                new_email: {type: string}
                new_password: {type: string}
        responses:
          200: {description: Profile updated}
          401: {description: Verification failed}
        """
        current_username = get_jwt_identity()
        user = User.query.filter_by(username=current_username).first()
        data = request.json

        # 1. Verify that the user is who they say they are
        if user.email != data.get('current_email') or user.password != data.get('current_password'):
            return jsonify({"message": "Identity verification failed. Incorrect email or password."}), 401

        # 2. Update fields if provided
        if 'new_username' in data:
            # Check if new username is taken
            if User.query.filter_by(username=data['new_username']).first():
                return jsonify({"message": "New username already taken"}), 400
            user.username = data['new_username']
        
        if 'new_email' in data:
            # Check if new email is taken
            if User.query.filter_by(email=data['new_email']).first():
                return jsonify({"message": "New email already taken"}), 400
            user.email = data['new_email']

        if 'new_password' in data:
            user.password = data['new_password']

        db.session.commit()
        
        # Note: If username changes, the old JWT becomes invalid on next request if identity is username-based.
        return jsonify({"message": "Credentials updated successfully. Please log in again if username was changed."}), 200
    
    @app.route('/user/delete_profile', methods=['DELETE'])
    @jwt_required()
    def delete_profile():
        """
        Delete User Account (Self Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [password]
              properties:
                password: {type: string, description: "Confirm password to delete account"}
        responses:
          200:
            description: Account deleted successfully
          401:
            description: Password verification failed
          404:
            description: User not found
        """
        current_username = get_jwt_identity()
        user = User.query.filter_by(username=current_username).first()
        data = request.json

        if not user:
            return jsonify({"message": "User not found"}), 404

        # Verify password before deletion for security
        if user.password != data.get('password'):
            return jsonify({"message": "Incorrect password. Deletion cancelled."}), 401

        # Optional: Delete associated cart items first if not using cascades
        CartItem.query.filter_by(user_id=user.id).delete()

        db.session.delete(user)
        db.session.commit()

        return jsonify({"message": f"Account '{current_username}' has been successfully deleted."}), 200
    
    
    # --- ERROR HANDLER ---
    # Optional: Customize the response when a user is rate-limited
    @app.errorhandler(429)
    def ratelimit_handler(e):
        return jsonify({
            "error": "ratelimit exceeded",
            "message": str(e.description)
        }), 429
    

    # --- PRODUCT ROUTES ---

    @app.route('/products', methods=['GET'])
    @jwt_required()
    def get_products():
        """
        Get all products
        ---
        security:
          - Bearer: []
        responses:
          200:
            description: A list of products
            schema:
              type: array
              items:
                properties:
                  id:
                    type: integer
                  name:
                    type: string
                  price:
                    type: number
                inventory: {type: integer, description: "Only visible to admins"}
          401:
            description: Missing or invalid token
        """
        products = Product.query.all()
        is_admin = check_admin() # Use your helper function
        
        product_list = []
        for p in products:
            # Create the base dictionary
            product_data = {
                "id": p.id,
                "name": p.name,
                "price": p.price
            }
            
            # Conditionally add inventory if the logged-in user is an admin
            if is_admin:
                product_data["inventory"] = p.inventory
                
            product_list.append(product_data)

        return jsonify(product_list)
    
    

    # --- CART ROUTES ---

    @app.route('/cart/add', methods=['POST'])
    @jwt_required()
    def add_to_cart():
        """
        Add to cart and deduct from inventory
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              properties:
                product_id: {type: integer}
                quantity: {type: integer, default: 1}
        responses:
          201: {description: Added to cart}
          400: {description: Insufficient stock}
        """
        username = get_jwt_identity()
        user = User.query.filter_by(username=username).first()
        data = request.json

        product_id = data.get('product_id')
        quantity = data.get('quantity', 1) 

        product = Product.query.get(product_id)
        if not product:
            return jsonify({"message": "Product not found"}), 404

        # --- INVENTORY CHECK ---
        if product.inventory < quantity:
            return jsonify({
                "message": f"Insufficient stock. Only {product.inventory} left."
            }), 400

        # Deduct from inventory immediately to "reserve" the items
        product.inventory -= quantity

        existing_item = CartItem.query.filter_by(user_id=user.id, product_id=product_id).first()
        if existing_item:
            existing_item.quantity += quantity
        else:
            new_item = CartItem(user_id=user.id, product_id=product_id, quantity=quantity)
            db.session.add(new_item)

        db.session.commit()
        return jsonify({"message": "Added to cart", "remaining_stock": product.inventory}), 201
    
    @app.route('/cart', methods=['GET'])
    @jwt_required()
    def view_cart():
        """
        View current user's shopping cart
        ---
        security:
          - Bearer: []
        responses:
          200:
            description: List of items in the cart with total price
            schema:
              properties:
                items:
                  type: array
                  items:
                    properties:
                      product_id: {type: integer}
                      product_name: {type: string}
                      price_per_unit: {type: number}
                      quantity: {type: integer}
                      subtotal: {type: number}
                grand_total: {type: number}
          401:
            description: Unauthorized
        """
        username = get_jwt_identity()
        user = User.query.filter_by(username=username).first()
        
        # Query cart items for this user
        cart_items = CartItem.query.filter_by(user_id=user.id).all()
        
        output = []
        grand_total = 0
        
        for item in cart_items:
            product = Product.query.get(item.product_id)
            if product:
                subtotal = product.price * item.quantity
                grand_total += subtotal
                output.append({
                    "product_id": product.id,
                    "product_name": product.name,
                    "price_per_unit": product.price,
                    "quantity": item.quantity,
                    "subtotal": subtotal
                })
        
        return jsonify({
            "items": output,
            "grand_total": grand_total
        }), 200
    
    @app.route('/cart/update', methods=['POST'])
    @jwt_required()
    def update_cart():
        """
        Reduce quantity or remove item from cart
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required: [product_id, action]
              properties:
                product_id: {type: integer}
                action: {type: string, enum: [reduce, remove], example: reduce}
                quantity: {type: integer, default: 1, description: "Amount to reduce by if action is 'reduce'"}
        responses:
          200: {description: Cart updated successfully}
          404: {description: Item not found in cart}
        """
        username = get_jwt_identity()
        user = User.query.filter_by(username=username).first()
        data = request.json
        
        product_id = data.get('product_id')
        action = data.get('action') # 'reduce' or 'remove'
        reduce_qty = data.get('quantity', 1)

        cart_item = CartItem.query.filter_by(user_id=user.id, product_id=product_id).first()
        product = Product.query.get(product_id)

        if not cart_item:
            return jsonify({"message": "Item not found in your cart"}), 404

        if action == 'remove' or (action == 'reduce' and cart_item.quantity <= reduce_qty):
            # Return ALL units back to inventory
            if product:
                product.inventory += cart_item.quantity
            db.session.delete(cart_item)
            message = "Item removed from cart"
        
        elif action == 'reduce':
            # Return specified units back to inventory
            cart_item.quantity -= reduce_qty
            if product:
                product.inventory += reduce_qty
            message = f"Quantity reduced by {reduce_qty}"

        db.session.commit()
        return jsonify({"message": message, "current_inventory": product.inventory if product else "N/A"}), 200
    

    #only admin can access
    @app.route('/admin/products/<int:id>/restock', methods=['PUT'])
    @jwt_required()
    def restock_product(id):
        """
        Update product inventory level (Admin Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: id
            in: path
            required: true
            type: integer
          - name: body
            in: body
            required: true
            schema:
              properties:
                added_stock: {type: integer, example: 100}
        """
        if not check_admin():
            return jsonify({"message": "Admin privilege required"}), 403

        product = Product.query.get(id)
        if not product:
            return jsonify({"message": "Product not found"}), 404

        data = request.json
        product.inventory += data.get('added_stock', 0)
        db.session.commit()

        return jsonify({"message": f"New inventory for {product.name}: {product.inventory}"}), 200

    @app.route('/checkout', methods=['GET'])
    @jwt_required()
    def checkout():
        """
        Calculate total price and clear cart
        ---
        security:
          - Bearer: []
        responses:
          200:
            description: Checkout successful
            schema:
              properties:
                total_price: {type: number}
                status: {type: string}
                items_purchased: {type: integer}
          400:
            description: Cart is empty
        """
        username = get_jwt_identity()
        user = User.query.filter_by(username=username).first()
        items = CartItem.query.filter_by(user_id=user.id).all()

        if not items:
            return jsonify({"message": "Cart is empty"}), 400

        total = 0
        for item in items:
            product = Product.query.get(item.product_id)
            if product:
                # Calculation: Price * Quantity
                total += (product.price * item.quantity)

        CartItem.query.filter_by(user_id=user.id).delete()
        db.session.commit()

        return jsonify({
            "total_price": total, 
            "status": "Paid",
            "message": "Thank you for your purchase!"
        }), 200
        
        return jsonify({"total_price": total, "status": "Paid"}), 200

    # --- ADMIN CONTROLLED ROUTES ---

    @app.route('/admin/products', methods=['POST'])
    @jwt_required()
    def add_product():
        """
        Add a new product with inventory (Admin Only)
        ---
        security:
          - Bearer: []
        parameters:
          - name: body
            in: body
            required: true
            schema:
              required:
                - name
                - price
                - inventory
              properties:
                name: {type: string}
                price: {type: number}
                inventory: {type: integer, example: 50}
        responses:
          201:
            description: Product added successfully
        """
        if not check_admin():
            return jsonify({"message": "Admin privilege required"}), 403
        
        data = request.json
        new_product = Product(
            name=data['name'], 
            price=data['price'], 
            inventory=data.get('inventory', 0)
        )
        db.session.add(new_product)
        db.session.commit()
        return jsonify({"message": f"Product {data['name']} added to inventory"}), 201

    @app.route('/admin/products/<int:id>', methods=['DELETE'])
    @jwt_required()
    def delete_product(id):
        """
        Delete a product (Admin Only)
        ---
        tags:
          - Admin Actions
        security:
          - Bearer: []
        parameters:
          - name: id
            in: path
            type: integer
            required: true
            description: The ID of the product to delete
        responses:
          200:
            description: Product deleted successfully
            schema:
              properties:
                message:
                  type: string
                  example: Product deleted
          403:
            description: Admin privilege required
          404:
            description: Product not found
          401:
            description: Unauthorized (Token missing or invalid)
        """
        if not check_admin():
            return jsonify({"message": "Admin privilege required"}), 403
        
        product = Product.query.get(id)
        if product:
            db.session.delete(product)
            db.session.commit()
            return jsonify({"message": "Product deleted"}), 200
        return jsonify({"message": "Product not found"}), 404

    @app.route('/admin/users', methods=['GET'])
    @jwt_required()
    def list_users():
        """
        Delete a product (Admin Only)
        ---
        security:
          - Bearer: []
        
        responses:
          200:
            description: Product deleted successfully
          403:
            description: Admin privilege required
          404:
            description: Product not found
        """
        if not check_admin():
            return jsonify({"message": "Admin privilege required"}), 403
        
        users = User.query.all()
        return jsonify([{"id": u.id, "username": u.username, "is_admin": u.is_admin} for u in users])

    return app




